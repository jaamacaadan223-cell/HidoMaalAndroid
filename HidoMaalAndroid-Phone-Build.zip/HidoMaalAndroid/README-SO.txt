HIDO MAAL ACADEMY — ANDROID WEBVIEW PROJECT
===========================================

Mashruucani waa Android Studio project (source code), ma aha APK la dhisay.
Website-ka lama koobiyeeyn mana beddelayo PHP/MySQL backend-ka. App-ku wuxuu furayaa:
https://hiddomaal.freepage.cc/

SIDA LOO DHISO APK
------------------
1. Ku fur folder-kan Android Studio kombiyuutar leh Android SDK.
2. Sug Gradle Sync inuu dhammaado.
3. Dooro Build > Build APK(s).
4. APK-ga debug wuxuu badanaa ka muuqdaa app/build/outputs/apk/debug/app-debug.apk.
5. APK-gaas waa la diri karaa (Xender, Bluetooth, WhatsApp iwm). Qalabka qaataha waa inuu oggolaadaa rakibidda apps ka baxsan Play Store.
6. APK loogu talagalay qaybinta joogtada ah, samee signed release APK gudaha Build > Generate Signed Bundle / APK.

WEBSITE UPDATE vs APK UPDATE
----------------------------
- Isbeddelada bogagga website-ka waxay muuqanayaan marka app-ku internet helo.
- APK update checker-ku wuxuu akhriyaa URL-kan:
  https://hiddomaal.freepage.cc/app-version.json
- Faylka tusaalaha ah ee app-version.json wuxuu ku jiraa folder-ka server-config/.
- Ku upload garee app-version.json root-ka website-ka. Markaad sii dayso APK cusub, beddel versionCode, versionName iyo apkUrl si ay u tilmaamaan APK-ga cusub.
- Android ma oggola in app-ku iskiis u rakibo APK update-ka. User-ku waa inuu soo dejiyo oo xaqiijiyo rakibidda.
- Si app-ku u arko nooc cusub, kordhi APP_VERSION_CODE gudaha MainActivity.java, kordhi versionCode/versionName gudaha app/build.gradle.kts, kadibna dib u dhis oo saxiix APK cusub.

MUHIIM
-----
- App-ku wuxuu u baahan yahay internet si uu u galo website-ka. Haddii hosting-ka ama domain-ku is beddelo, HOME_URL iyo VERSION_URL waa in la cusboonaysiiyaa.
- Website-kaaga waa PHP/MySQL; Android app-ku ma beddelayo hosting-ka ama database-ka.
- Haddii website-ka laftiisu leeyahay cillad, WebView-ku ma hagaajinayo cilladdaas.
- APK-ga release-ka waa in lagu saxiixaa isla signing key-ga marka la sameynayo updates mustaqbalka; kaydi key-ga si ammaan ah.
