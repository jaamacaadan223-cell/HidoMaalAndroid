plugins { id("com.android.application") }

android {
    namespace = "cc.freepage.hiddomaal"
    compileSdk = 35

    defaultConfig {
        applicationId = "cc.freepage.hiddomaal"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
